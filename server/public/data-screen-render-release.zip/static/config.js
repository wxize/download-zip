window.g = {
  PROJECT_ROOT_NAME: '/',
  // PROJECT_ROOT_NAME: '/bricks/datascreen',
  SYS_NAME: 'Bricks',
  SYS_VERSION: '企业版',
  // AXIOS_BASE_URL: 'http://10.9.13.16/:8090'
  // AXIOS_BASE_URL: 'http://localhost:80',
  AXIOS_BASE_URL: 'http://210.14.149.117:8888',
  API_VERSION: '/api/v1'
};
